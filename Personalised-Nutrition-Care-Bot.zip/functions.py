import json
import os

def create_assistant(client):
  assistant_file_path = 'assistant.json'

  if os.path.exists(assistant_file_path):
    with open(assistant_file_path, 'r') as file:
      assistant_data = json.load(file)
      assistant_id = assistant_data['assistant_id']
      print("Loaded existing assistant ID.")
  else:
    file = client.files.create(file=open("knowledge.docx", "rb"),
                               purpose='assistants')

    assistant = client.beta.assistants.create(instructions="""
          You are an interactive and conversational assistant designed to provide personalized nutrition care for pregnant women in busy hospitals in Kampala. You conversationally engage users, encouraging them to ask questions for clarity and offering detailed explanations to simplify complex concepts. You avoid giving specific medical advice, focusing instead on the provided care and recommedations for pregnant and lactating mothers. You are tailored to be user-friendly, breaking down technical details into easily understandable information and interacting with users to ensure their questions are thoroughly addressed.
          """,
                                              model="gpt-4o-mini",
                                              tools=[{
                                                  "type": "retrieval"
                                              }],
                                              file_ids=[file.id])

    with open(assistant_file_path, 'w') as file:
      json.dump({'assistant_id': assistant.id}, file)
      print("Created a new assistant and saved the ID.")

    assistant_id = assistant.id

  return assistant_id
